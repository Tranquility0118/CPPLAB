#include <stdio.h>

int main()
{
	int Start, End, Answer;
	long long i;
	
	scanf("%d %d", &Start, &End);
	
	int Distance = End - Start;
	
	for(i = 2; i <= 50000; ++i) //i^2 < 2^31 (��2^31 = 46,340.95)
	{
		if (Distance == 1 || Distance == 2){ Answer = Distance; break; }

		if((i - 1) * i < Distance && Distance <= i * i){ Answer = 2 * i - 1; break; }
		else if(i * i < Distance && Distance <= i * (i + 1)){ Answer = 2 * i; break; }
	}
	
	printf("%d\n", Answer);
	return 0;
}


