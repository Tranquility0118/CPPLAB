#include <stdio.h>
#include <math.h>

int main()
{
	int Start, End;
	scanf("%d %d", &Start, &End);
	
	int Distance = End - Start;
	double Temp = sqrt(Distance);
	int Answer = (int)(Temp / 0.5);
	
	printf("%d\n", (Temp == (int)Temp) ? Answer - 1 : Answer);
	
	return 0;
}


