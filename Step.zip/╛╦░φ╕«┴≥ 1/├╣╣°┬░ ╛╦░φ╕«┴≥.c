#include <stdio.h>

int Function(int Distance, int Step, int Count) //���� �Ÿ�, ���� ���� �Ÿ�, ������ Ƚ��
{
	if(Distance == 0 && Step == 1) return Count;
	
	int StepSum = Step * (Step - 1) / 2;
	if(StepSum > Distance) return -1;
	
	int ret;
	
	ret = Function(Distance - (Step + 1),  Step + 1, Count + 1);
	if(ret > 0) return ret;
	
	ret = Function(Distance - Step, Step, Count + 1);
	if(ret > 0) return ret;
	
	ret = Function(Distance - (Step - 1),  Step - 1, Count + 1);
	if(ret > 0) return ret;
	
	return -1;
}

int main()
{
	int Start, End;
	
	scanf("%d %d", &Start, &End);
	
	int Distance = End - Start;
	
	printf("%d\n", Function(Distance - 1, 1, 1));
	
	return 0;
}


